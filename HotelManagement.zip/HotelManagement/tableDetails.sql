create table RoomDeatils(roomNumber number,
floor number,
roomType varchar(30),
roomServics varchar(30),
price number);
create table OccupancyDeatils(
	 personName varchar(50),
	 personId varchar(50),
	checkIn varchar(50),
	checkOut varchar(50),
	 contactNumber varchar(50),
	 amountPaidInAdv number);
create table CabDeatils(driverContactNumber number,
	 bookedPerson varchar(50));
ALTER TABLE RoomDeatils ADD PRIMARY KEY (roomNumber);   
	 insert into RoomDeatils values(101,1,'Delux','Available',5000);
	 ALTER TABLE OccupancyDeatils add roomNumber number;
	 ALTER TABLE OccupancyDeatils 
ADD FOREIGN KEY (roomNumber) REFERENCES RoomDeatils(roomNumber);
insert into OCCUPANCYDEATILS values('Abirami','13N201','01-08-2017','20-08-2017','8754839090',2000,101);
select * from OccupancyDeatils;
SELECT * from  RoomDeatils natural join OccupancyDeatils where OccupancyDeatils.checkin='01-08-2017' and OccupancyDeatils.checkout='20-08-2017';