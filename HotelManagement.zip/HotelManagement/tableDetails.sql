create table RoomDeatils(roomNumber number,
floor number,
roomType varchar(30),
roomServics varchar(30),
price number);

create table CabDeatils(driverContactNumber number,
	 bookedPerson varchar(50));
ALTER TABLE RoomDeatils ADD PRIMARY KEY (roomNumber);   
	 insert into RoomDeatils values(101,1,'Delux','Available',5000);
	 ALTER TABLE OccupancyDeatils add roomNumber number;
	 ALTER TABLE OccupancyDeatils 
ADD FOREIGN KEY (roomNumber) REFERENCES RoomDeatils(roomNumber);
insert into OCCUPANCYDEATILS values('Abirami','13N201','01-Aug-2017','20-Aug-2017','8754839090',2000,101);

select * from OccupancyDeatils;
SELECT * from  RoomDeatils natural join OccupancyDeatils where OccupancyDeatils.checkin='01-08-2017' and OccupancyDeatils.checkout='20-08-2017';
 insert into RoomDeatils values(201,2,'MultiDelux','Available',6000);
 insert into OCCUPANCYDEATILS values('Sangeetha','13N224','01-Sep-2017','20-Sep-2017','1234567890',2000,201);
 SELECT * from  RoomDeatils natural join OccupancyDeatils where OccupancyDeatils.checkin=to_char(sysdate,'dd-Mon-yyyy'); 
 drop table OccupancyDeatils;
 create table OccupancyDeatils(
	 personName varchar(50),
	 personId varchar(50),
	checkIn date,
	checkOut date,
	 contactNumber varchar(50),
	 amountPaidInAdv number);
	  ALTER TABLE OccupancyDeatils add roomNumber number;
 ALTER TABLE OccupancyDeatils 
ADD FOREIGN KEY (roomNumber) REFERENCES RoomDeatils(roomNumber);

select to_char(sysdate,'dd-Mon-yyyy') from dual;