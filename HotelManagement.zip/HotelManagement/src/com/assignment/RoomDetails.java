package com.assignment;

public class RoomDetails {
private  int roomNumber;
private int floor;
private String roomType;
private String roomServics;
private double price;

public RoomDetails() {
	super();
}
public RoomDetails(int roomNumber, int floor, String roomType,
		String roomServics, double price) {
	super();
	this.roomNumber = roomNumber;
	this.floor = floor;
	this.roomType = roomType;
	this.roomServics = roomServics;
	this.price = price;
}

public int getRoomNumber() {
	return roomNumber;
}
public void setRoomNumber(int roomNumber) {
	this.roomNumber = roomNumber;
}
public int getFloor() {
	return floor;
}
public void setFloor(int floor) {
	this.floor = floor;
}
public String getRoomType() {
	return roomType;
}
public void setRoomType(String roomType) {
	this.roomType = roomType;
}
public String getRoomServics() {
	return roomServics;
}
public void setRoomServics(String roomServics) {
	this.roomServics = roomServics;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
@Override
public String toString() {
	return "RoomDetails [roomNumber=" + roomNumber + ", floor=" + floor
			+ ", roomType=" + roomType + ", roomServics=" + roomServics
			+ ", price=" + price + "]";
}

}
