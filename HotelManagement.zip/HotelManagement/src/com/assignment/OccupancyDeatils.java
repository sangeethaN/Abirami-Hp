package com.assignment;

public class OccupancyDeatils {
	private String personName;
	private String personId;
	private String checkIn;
	private String checkOut;
	private String contactNumber;
	private double amountPaidInAdv;
	private int RoomNumber;
	public OccupancyDeatils(String personName, String personId, String checkIn,
			String checkOut, String contactNumber, double amountPaidInAdv,
			int roomNumber) {
		super();
		this.personName = personName;
		this.personId = personId;
		this.checkIn = checkIn;
		this.checkOut = checkOut;
		this.contactNumber = contactNumber;
		this.amountPaidInAdv = amountPaidInAdv;
		RoomNumber = roomNumber;
	}
	public OccupancyDeatils() {
		super();
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getPersonId() {
		return personId;
	}
	public void setPersonId(String personId) {
		this.personId = personId;
	}
	public String getCheckIn() {
		return checkIn;
	}
	public void setCheckIn(String checkIn) {
		this.checkIn = checkIn;
	}
	public String getCheckOut() {
		return checkOut;
	}
	public void setCheckOut(String checkOut) {
		this.checkOut = checkOut;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public double getAmountPaidInAdv() {
		return amountPaidInAdv;
	}
	public void setAmountPaidInAdv(double amountPaidInAdv) {
		this.amountPaidInAdv = amountPaidInAdv;
	}
	public int getRoomNumber() {
		return RoomNumber;
	}
	public void setRoomNumber(int roomNumber) {
		RoomNumber = roomNumber;
	}
	@Override
	public String toString() {
		return "OccupancyDeatils [personName=" + personName + ", personId="
				+ personId + ", checkIn=" + checkIn + ", checkOut=" + checkOut
				+ ", contactNumber=" + contactNumber + ", amountPaidInAdv="
				+ amountPaidInAdv + ", RoomNumber=" + RoomNumber + "]";
	}
	

}
