package com.assignment;

public class CabDetails {
	private String driverContactNumber;
	private String bookedPerson;
	public CabDetails(String driverContactNumber, String bookedPerson) {
		super();
		this.driverContactNumber = driverContactNumber;
		this.bookedPerson = bookedPerson;
	}
	public String getDriverContactNumber() {
		return driverContactNumber;
	}
	public void setDriverContactNumber(String driverContactNumber) {
		this.driverContactNumber = driverContactNumber;
	}
	public String getBookedPerson() {
		return bookedPerson;
	}
	public void setBookedPerson(String bookedPerson) {
		this.bookedPerson = bookedPerson;
	}
	

}
