package com.assignment;

import java.sql.SQLException;

public class ProjectMain {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
	ProjectDao room = new ProjectDao();
	//room.details();
RoomDetails obj=room.details();
System.out.println(obj.toString());
OccupancyDeatils obj1 =room.occupancy();
System.out.println(obj1.toString());
room.result();


	}

}
