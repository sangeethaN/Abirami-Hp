package com.assignment;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProjectDao {
	public RoomDetails details() throws SQLException {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;

		ResultSet resultset = null;
		String searchQuery = "SELECT * from RoomDeatils";

		stmt = conn.prepareStatement(searchQuery);

		resultset = stmt.executeQuery();

		RoomDetails B1 = null;

		while (resultset.next()) {
			B1 = new RoomDetails();
			B1.setRoomNumber(resultset.getInt("roomNumber"));
			B1.setFloor(resultset.getInt("floor"));
			B1.setRoomType(resultset.getString("roomType"));
			B1.setRoomServics(resultset.getString("roomServics"));
			B1.setPrice(resultset.getDouble("price"));

		}

		return B1;
	}

	public OccupancyDeatils occupancy() throws SQLException {

		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;

		ResultSet resultset = null;
		String searchQuery = "SELECT * from OccupancyDeatils";

		stmt = conn.prepareStatement(searchQuery);

		resultset = stmt.executeQuery();

		OccupancyDeatils B1 = null;

		while (resultset.next()) {
			B1 = new OccupancyDeatils();
			B1.setPersonName(resultset.getString("personName"));
			B1.setPersonId(resultset.getString("personId"));
			B1.setCheckIn(resultset.getString("checkIn"));
			B1.setCheckOut(resultset.getString("checkOut"));
			B1.setContactNumber(resultset.getString("contactNumber"));
			B1.setAmountPaidInAdv(resultset.getDouble("amountPaidInAdv"));

			B1.setRoomNumber(resultset.getInt("roomNumber"));

		}

		return B1;
	}

	public void result() throws SQLException {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;

		ResultSet resultset = null;
		String searchQuery = "SELECT * from  RoomDeatils natural join OccupancyDeatils where OccupancyDeatils.checkin='01-08-2017' and OccupancyDeatils.checkout='20-08-2017'";

		stmt = conn.prepareStatement(searchQuery);

		resultset = stmt.executeQuery();
		while (resultset.next()) {

			System.out.println("RoomNumber: " + resultset.getInt(1) + "\n"
					+ "Floor: " + resultset.getInt(2) + "\n" + "RoomType: "
					+ resultset.getString(3) + "\n" + "RoomService: "
					+ resultset.getString(4) + "\n" + "Price: "
					+ resultset.getDouble(5) + "\n" + "PersonName: "
					+ resultset.getString(6) + "\n" + "PersonId: "
					+ resultset.getString(7) + "\n" + "CheckIn: "
					+ resultset.getString(8) + "\n" + "CheckOut: "
					+ resultset.getString(9) + "\n" + "ContactNumber: "
					+ resultset.getString(10) + "\n" + "AmountPaidInAdv: "
					+ resultset.getDouble(11));
		}

	}
}
